<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-user"></i> Profile</h3>
			</div>
			<?php echo Form::open(['route' => 'update_profile', 'method' => 'POST', 'autocomplete' => 'off']); ?>

			<div class="card-body">
				<div class="form-group">
					<label>Name:</label>
					<input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>" />
				</div>
				<div class="form-group">
					<label>Email:</label>
					<input type="email" name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" />
				</div>
				<div class="form-group">
					<label>Role:</label>
					<input type="text" readonly="readonly" name="role" class="form-control" value="<?php echo e(Auth::user()->role); ?>" />
				</div>
				<?php if(Auth::user()->role == 'admin'): ?>
					<!--<div class="form-group">
						<label>Import Current Page: </label>
						<input type="text" class="form-control" readonly="readonly" value="<?php echo e($current_page); ?>" />
					</div>-->
				<?php endif; ?>
			</div>
			<div class="card-footer text-right">
				<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
			</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-key"></i> Change Password</h3>
			</div>
			<?php echo Form::open(['route' => 'change_password', 'method' => 'POST']); ?>

			<div class="card-body">
				<div class="form-group">
					<label>Password: </label>
					<input type="password" name="password" class="form-control" />
				</div>
				<div class="form-group">
					<label>Repeat Password: </label>
					<input type="password" name="password_confirmation" class="form-control" />
				</div>
			</div>
			<div class="card-footer text-right">
				<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
			</div>
			<?php echo Form::close(); ?>

		</div>		
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		<?php if(Session::has('success')): ?>

			Swal.fire({
				title: "<?php echo e(Session::get('success')); ?>",
				type: "success"
			});
			
		<?php endif; ?>

		<?php if(Session::has('error')): ?>

			Swal.fire({
				title: "<?php echo e(Session::get('error')); ?>",
				type: "error"
			});
			
		<?php endif; ?>
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/users/profile.blade.php ENDPATH**/ ?>