<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-tv"></i> <?php echo e($title); ?></h3>
			</div>
			<?php if($type == 'new'): ?>
				<?php echo Form::open(['route' => 'channels.store', 'method' => 'POST', 'autocomplete' => 'off', 'files' => true]); ?>

			<?php else: ?>
				<?php echo Form::open(['route' => ['channels.update',$data->id], 'method' => 'PUT', 'autocomplete' => 'off', 'files' => true]); ?>

			<?php endif; ?>
				<div class="card-body">
					<div class="form-group">
						<label>Title:</label>
						<input type="text" name="title" class="form-control" value="<?php echo e(@$data->title); ?>" />
					</div>
					<div class="form-group">
						<label>Category:</label>
						<select class="form-control" name="category_id">
							<option>-</option>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($category->id); ?>" <?php if(@$data->category_id == $category->id): ?> selected='selected' <?php endif; ?>><?php echo e($category->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<label>Description:</label>
						<textarea class="form-control" name="description"><?php echo e(@$data->description); ?></textarea>
					</div>
					<div class="form-group">
						<label>Poster:</label>
						<input type="file" name="poster" class="form-control" />
						<?php if(!empty(@$data->poster)): ?>
							<img src="<?php echo e(asset('storage/channels/'.@$data->poster)); ?>" class="img-thumbnail" style="width: 200px; height: 200px; margin-top: 15px;">
						<?php endif; ?>
					</div>
					<div class="form-group">
						<label>Url:</label>
						<input type="text" name="url" class="form-control" value="<?php echo e(@$data->url); ?>" />
					</div>
				</div>
				<div class="card-footer text-right">
					<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
					<a href="<?php echo e(route('channels.index')); ?>" class="btn btn-danger"><i class="fas fa-times"></i> Cancel</a>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/channels/form.blade.php ENDPATH**/ ?>