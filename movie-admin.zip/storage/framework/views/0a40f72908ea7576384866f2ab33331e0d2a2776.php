<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">	
		<div class="col-md-12">
			<div class="card card-success">
				<div class="card-header">
					<h3><i class="fas fa-tv"></i> <?php echo e($title); ?></h3>
				</div>
				<div class="card-body">
					<a href="<?php echo e(route('channels.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i> New Channel</a>
					<br />
					<br />
					<table class="table table-bordered table-striped">
						<thead>
							<th>ID</th>
							<th>Title</th>
							<th>Category</th>
							<th>Description</th>
							<th>Poster</th>
							<th>-</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($channel->id); ?></td>
									<td><?php echo e($channel->title); ?></td>
									<td>
										<?php if(isset($channel->category_id) and !empty($channel->category_id)): ?>
											<?php echo e($channel->category->name); ?>

										<?php else: ?>
											No Category
										<?php endif; ?>
									</td>
									<td><?php echo e($channel->description); ?></td>
									<td>
									<?php if(isset($channel->poster)): ?>
											<img src="<?php echo e(asset('storage/channels/'.$channel->poster)); ?>" class="img-thumbnail" style="width: 150px; height: 150px;" />
										<?php else: ?>
											<span class="badge badge-info">Not Image</span>
										<?php endif; ?>
									</td>
									<td>
										<a href="<?php echo e(route('channels.edit',[$channel->id])); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
										<?php echo Form::open(['route' => ['channels.destroy',$channel->id], 'method' => 'DELETE', 'style' => 'display:inline;', 'id' => 'delete_'.$channel->id]); ?>

											<button data-id="<?php echo e($channel->id); ?>" class="delete btn <?php if($channel->status == 'A'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?>" type="button"><?php if($channel->status == 'A'): ?> <i class="fas fa-times"></i> <?php else: ?> <i class="fas fa-plus"></i> <?php endif; ?></button>
										<?php echo Form::close(); ?>

									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$("table.table").DataTable();

	$("body").on('click','.delete', function(){	

		Swal.fire({
			title: "Are you sure to perform this action?",
			type: 'question',
			showCancelButton: true
		}).then((result) => {
			if(result.value){
				let id = $(this).attr("data-id");
				$("#delete_"+id).submit();
			}
		});
	});

	<?php if(Session::has('success')): ?>

		Swal.fire({
			title: "<?php echo e(Session::get('success')); ?>",
			type: "success"
		});
		
	<?php endif; ?>

	<?php if(Session::has('error')): ?>

		Swal.fire({
			title: "<?php echo e(Session::get('error')); ?>",
			type: "error"
		});
		
	<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/channels/index.blade.php ENDPATH**/ ?>