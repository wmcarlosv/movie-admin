<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">	
		<div class="col-md-12">
			<div class="card card-success">
				<div class="card-header">
					<h3><i class="fas fa-ticket-alt"></i> <?php echo e($title); ?></h3>
				</div>
				<div class="card-body">
					<a href="<?php echo e(route('movies.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i> New Movie</a>
					<br />
					<br />
					<div class="row" style="margin-bottom: 20px;">
						<div class="col-md-6">
							<div class="search">
								<?php echo Form::open(['route' => 'movies.index', 'method' => 'GET']); ?>

								<div class="input-group">
									<input type="text" name="q" value="<?php echo e(@$q); ?>" id="q" class="form-control" />
									<div class="input-group-append">
										<button class="btn btn-success"><i class="fas fa-search"></i></button>
									</div>
								</div>
								<?php echo Form::close(); ?>

							</div>
						</div>
						<div class="col-md-6">
							<div id="pagination" style="float:right;">
								<?php echo e($data->appends(['q' => $q])->links()); ?>

							</div>
						</div>
					</div>

					<table class="table table-bordered table-striped">
						<thead>
							<th>ID</th>
							<th>Title</th>
							<th>Poster</th>
							<th>Categories</th>
							<th>Year</th>
							<th>Views</th>
							<th>Downloads</th>
							<th>Status</th>
							<th>-</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($movie->id); ?></td>
									<td width="300"><?php echo e($movie->title); ?></td>
									<td>
										<?php if(isset($movie->poster)): ?>
											<img src="<?php echo e(asset('storage/movies/'.$movie->poster)); ?>" class="img-thumbnail" style="width: 150px; height: 150px;" />
										<?php else: ?>
											<span class="badge badge-info">Not Image</span>
										<?php endif; ?>
									</td>
									<td width="200">
										<?php $__currentLoopData = $movie->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<span class="badge badge-info"><?php echo e($category->name); ?></span>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>
									<td><?php echo e($movie->year); ?></td>
									<td><?php echo e($movie->views); ?></td>
									<td><?php echo e($movie->downloads); ?></td>
									<td>
										<?php if($movie->status == 'A'): ?>
											<span class="badge badge-success">Active</span>
										<?php else: ?>
											<span class="badge badge-danger">Inactive</span>
										<?php endif; ?>
									</td>
									<td>
										<a href="<?php echo e(route('movies.edit',[$movie->id])); ?>" class="btn btn-info"><i class="fas fa-edit"></i></a>
										<?php echo Form::open(['route' => ['movies.destroy',$movie->id], 'method' => 'DELETE', 'style' => 'display:inline;', 'id' => 'delete_'.$movie->id]); ?>

											<button data-id="<?php echo e($movie->id); ?>" class="delete btn <?php if($movie->status == 'A'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?>" type="button"><?php if($movie->status == 'A'): ?> <i class="fas fa-times"></i> <?php else: ?> <i class="fas fa-plus"></i> <?php endif; ?></button>
										<?php echo Form::close(); ?>

									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<div id="pagination" style="float:right; margin-top: 20px;">
						<?php echo e($data->appends(['q' => $q])->links()); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

	$(".delete").click(function(e){	

		Swal.fire({
			title: "Are you sure to perform this action?",
			type: 'question',
			showCancelButton: true
		}).then((result) => {
			if(result.value){
				let id = $(this).attr("data-id");
				$("#delete_"+id).submit();
			}
		});
	});

	<?php if(Session::has('success')): ?>

		Swal.fire({
			title: "<?php echo e(Session::get('success')); ?>",
			type: "success"
		});
		
	<?php endif; ?>

	<?php if(Session::has('error')): ?>

		Swal.fire({
			title: "<?php echo e(Session::get('error')); ?>",
			type: "error"
		});
		
	<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/movies/index.blade.php ENDPATH**/ ?>