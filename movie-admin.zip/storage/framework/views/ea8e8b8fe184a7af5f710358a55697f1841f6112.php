<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-file-import"></i> <?php echo e($title); ?></h3>
			</div>	
			<div class="card-body">
				<div class="row">
					<div class="col-md-12">
						<?php echo Form::open(['route' => 'set_import_movies', 'method' => 'POST']); ?>

						<div class="row">
							<div class="col-md-6">
								<div class="input-group">
									<input type="text" name="url" value="<?php echo e($q); ?>" placeholder="Url For Search Movie" class="form-control">
									<div class="input-group-append">
										<button type="submit" id="search-movies" class="btn btn-success"><i class="fas fa-search"></i></button>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-check">
									<div class="form-check-label">
										<input type="checkbox" name="search_type" <?php if(!empty($ts)): ?> checked='checked' <?php endif; ?> class="form-check-input"> Is Single Search
									</div>
								</div>
							</div>
						</div>
						<?php echo Form::close(); ?>

					</div>
				</div>
				<br />
				<div class="row">
					<div class="col-md-12">
						<?php if(count($data) > 0): ?>
							<button class="btn btn-success" id="save_movies" type="button"><i class="fas fa-save"></i> Save Movies</button>
							<br />
							<br />
						<?php endif; ?>
						<table class="table table-bordered table-striped">
							<thead>
								<th>Title</th>
								<th>Year</th>
								<th>Poster</th>
								<th>Categories</th>
								<th>Embed Urls</th>
							</thead>
							<tbody>
								<?php echo Form::open(['route' => 'save_movies', 'method' => 'POST', 'id' => 'form_movies']); ?>

								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imovie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>
											<input type="hidden" name="titles[]" value="<?php echo e($imovie['title']); ?>"/>
											<input type="hidden" name="descriptions[]" value="<?php echo e($imovie['description']); ?>"/>
										<?php echo e($imovie['title']); ?></td>
										<td><input type="hidden" name="years[]" value="<?php echo e($imovie['year']); ?>"/><?php echo e($imovie['year']); ?></td>
										<td>
											<input type="hidden" name="posters[]" value="<?php echo e($imovie['poster']); ?>"/>
											<img src="<?php echo e($imovie['poster']); ?>" style="width: 100px; height: 100px" />
										</td>
										<td><input type="hidden" name="categories[]" value="<?php echo e($imovie['categories']); ?>"/><?php echo e($imovie['categories']); ?></td>
										<td><input type="hidden" name="embed_url[]" value="<?php echo e($imovie['embed_urls']); ?>"/>
											<ul>
												<?php $__currentLoopData = json_decode($imovie['embed_urls']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><a href="<?php echo e($url->url); ?>" target="_blank"><?php echo e($url->server); ?> (<?php echo e($url->tab); ?>)</a></li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
										</td>
										<!--<td><button title="Test Movie" type="button" class="btn btn-success test-movie" data-code="<?php echo e($imovie['embed_urls']); ?>"><i class="fas fa-eye"></i></button></td>-->
										<td></td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php echo Form::close(); ?>

							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- The Modal -->
<div class="modal" id="movie-view-modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">View Movie In Player</h4>
        <button type="button" class="close close-modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<h3>Quality</h3>
      	<hr />
        <center><div class="btn-group" id="qlf"></div></center>
        <hr />
        <div id="player"></div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger close-modal">Close</button>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){

		$(".test-movie").click(function(){
			let api_code = $(this).attr('data-code');

			$.post("<?php echo e(route('getDataVideo')); ?>", { api_code: api_code, _token: "<?php echo e(csrf_token()); ?>" }, function(data){
				let files = JSON.parse(data);
				
		    	let html = "";
		    	$("#qlf").empty();
		    	$.each(files.data, function(index, value){
		    		html+="<button class='btn btn-info set-player' data-url='"+value.file+"' type='button'>"+value.label+"</button>";
		    	});
		    	$("#qlf").html(html);
		    	html = "";
			});

			$('#movie-view-modal').modal('show');
		});

		$("body").on('click','button.set-player', function(){
			let url_player = $(this).attr("data-url");
			$("#player").empty();
			$("#player").html("<video width='100%' height='240' controls><source src='<?php echo e(route('getVideo')); ?>?video_url="+url_player+"' type='video/mp4'/></video>");
		});

		$(".close-modal").click(function(){
			$("#player").empty();
			$('#movie-view-modal').modal('hide');
		});

		$("#save_movies").click(function(){
			$("#form_movies").submit();
		});

		<?php if(Session::has('success')): ?>

			Swal.fire({
				title: "<?php echo e(Session::get('success')); ?>",
				type: "success"
			});
			
		<?php endif; ?>

		<?php if(Session::has('error')): ?>

			Swal.fire({
				title: "<?php echo e(Session::get('error')); ?>",
				type: "error"
			});
			
		<?php endif; ?>

	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/imports/index.blade.php ENDPATH**/ ?>