<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-tag"></i> <?php echo e($title); ?></h3>
			</div>
			<?php if($type == 'new'): ?>
				<?php echo Form::open(['route' => 'applications.store', 'method' => 'POST', 'autocomplete' => 'off']); ?>

			<?php else: ?>
				<?php echo Form::open(['route' => ['applications.update',$data->id], 'method' => 'PUT', 'autocomplete' => 'off']); ?>

			<?php endif; ?>
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Name:</label>
								<input type="text" required="required" name="name" class="form-control" value="<?php echo e(@$data->name); ?>" />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Version:</label>
								<input type="text" required="required" name="version" class="form-control" value="<?php echo e(@$data->version); ?>" />
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<label>About:</label>
						<textarea class="form-control" required="required" name="about"><?php echo e(@$data->about); ?></textarea>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Play Store Url:</label>
								<input type="text" name="play_store_url" class="form-control" value="<?php echo e(@$data->play_store_url); ?>" />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>App Access Code:</label>
								<input type="text" maxlength="10" required="required" minlength="10" name="app_code" class="form-control" value="<?php echo e(@$data->app_code); ?>" />
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<label>Privacy Policy:</label>
						<textarea class="form-control" name="privacy_policy"><?php echo e(@$data->privacy_policy); ?></textarea>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>Url App Qualify:</label>
								<input type="text" name="url_qualify" class="form-control" value="<?php echo e(@$data->url_qualify); ?>" />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Url App More Apps:</label>
								<input type="text" name="url_more_apps" class="form-control" value="<?php echo e(@$data->url_more_apps); ?>" />
							</div>
						</div>
					</div>
				</div>
				<div class="card-footer text-right">
					<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
					<a href="<?php echo e(route('applications.index')); ?>" class="btn btn-danger"><i class="fas fa-times"></i> Cancel</a>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/applications/form.blade.php ENDPATH**/ ?>