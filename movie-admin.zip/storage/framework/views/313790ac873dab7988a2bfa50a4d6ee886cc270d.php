<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-tag"></i> <?php echo e($title); ?></h3>
			</div>
			<?php if($type == 'new'): ?>
				<?php echo Form::open(['route' => 'categories.store', 'method' => 'POST', 'autocomplete' => 'off']); ?>

			<?php else: ?>
				<?php echo Form::open(['route' => ['categories.update',$data->id], 'method' => 'PUT', 'autocomplete' => 'off']); ?>

			<?php endif; ?>
				<div class="card-body">
					<div class="form-group">
						<label>Name:</label>
						<input type="text" name="name" class="form-control" value="<?php echo e(@$data->name); ?>" />
					</div>
					<!--<div class="form-check">
					  <label class="form-check-label">
					    <input type="checkbox" name="is_for_channel" <?php if(@$data->is_for_channel == 'Y'): ?> checked='checked' <?php endif; ?> class="form-check-input" value="Y">Is For Channel
					  </label>-->
					</div>
				</div>
				<div class="card-footer text-right">
					<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
					<a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger"><i class="fas fa-times"></i> Cancel</a>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/categories/form.blade.php ENDPATH**/ ?>