<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-play"></i> <?php echo e($title); ?></h3>
			</div>
			<?php if($type == 'new'): ?>
				<?php echo Form::open(['route' => 'seasons.store', 'method' => 'POST', 'autocomplete' => 'off']); ?>

			<?php else: ?>
				<?php echo Form::open(['route' => ['seasons.update',$data->id], 'method' => 'PUT', 'autocomplete' => 'off']); ?>

			<?php endif; ?>
				<div class="card-body">
					<div class="form-group">
						<label>Serie:</label>
						<select class="form-control select-simple" name="serie_id">
							<option value="">-</option>
							<?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($serie->id); ?>" <?php if(@$data->serie_id == $serie->id): ?> selected='selected' <?php endif; ?>><?php echo e($serie->title); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<label>Title</label>
						<input type="text" name="title" class="form-control" value="<?php echo e(@$data->title); ?>">
					</div>
					<div class="form-group">
						<label>Position</label>
						<input type="text" name="position" class="form-control" value="<?php echo e(@$data->position); ?>">
					</div>
				</div>
				<div class="card-footer text-right">
					<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
					<a href="<?php echo e(route('seasons.index')); ?>" class="btn btn-danger"><i class="fas fa-times"></i> Cancel</a>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.Select2', true); ?>;
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('select.select-simple').select2();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/seasons/form.blade.php ENDPATH**/ ?>