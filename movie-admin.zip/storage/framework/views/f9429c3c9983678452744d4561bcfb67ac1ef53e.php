<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
	<h2><?php echo e($title); ?></h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>
		<div class="card card-success">
			<div class="card-header">
				<h3><i class="fas fa-ticket-alt"></i> <?php echo e($title); ?></h3>
			</div>
			<?php if($type == 'new'): ?>
				<?php echo Form::open(['route' => 'movies.store', 'method' => 'POST', 'autocomplete' => 'off', 'files' => true]); ?>

			<?php else: ?>
				<?php echo Form::open(['route' => ['movies.update',$data->id], 'method' => 'PUT', 'autocomplete' => 'off', 'files' => true]); ?>

			<?php endif; ?>
				<div class="card-body">
					<div class="form-group">
						<label>Title:</label>
						<input type="text" name="title" class="form-control" value="<?php echo e(@$data->title); ?>" />
					</div>
					<div class="form-group">
						<label>Description:</label>
						<textarea name="description" class="form-control"><?php echo e(@$data->description); ?></textarea>
					</div>
					<div class="form-group">
						<label>Categories:</label>
						<select class="form-control select-multiple" id="categories" name="categories[]" multiple="multiple">
							<option value="">-</option>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<label>Year:</label>
						<input type="text" name="year" class="form-control" value="<?php echo e(@$data->year); ?>" />
					</div>
					<div class="form-group">
						<label>Poster:</label>
						<input type="file" name="poster" class="form-control" />
						<?php if(!empty(@$data->poster)): ?>
							<img src="<?php echo e(asset('storage/movies/'.@$data->poster)); ?>" class="img-thumbnail" style="width: 200px; height: 200px; margin-top: 15px;">
						<?php endif; ?>
					</div>

					<?php if($type == "edit"): ?>
						<h2>Embed Urls</h2>
						<hr>
						<ul>
							<?php $__currentLoopData = json_decode(@$data->direct_url); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $embed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e($embed->url); ?>" target="_blank"><?php echo e($embed->server); ?> (<?php echo e($embed->tab); ?>)</a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					<?php else: ?>
						<div class="form-group">
							<label>Url:</label>
							<input type="hiden" name="direct_url" class="form-control" value="<?php echo e(@$data->direct_url); ?>" />
						</div>
					<?php endif; ?>
				</div>
				<div class="card-footer text-right">
					<?php if($type == 'edit'): ?>
					<!--<a class="btn btn-info test-movie" href="#" data-code="<?php echo e(@$data->api_code); ?>"><i class="fas fa-eye"></i></a>-->
					<?php endif; ?>
					<button class="btn btn-success" type="submit"><i class="fas fa-save"></i> Save</button>
					<a href="<?php echo e(route('movies.index')); ?>" class="btn btn-danger"><i class="fas fa-times"></i> Cancel</a>
				</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<!-- The Modal -->
<div class="modal" id="movie-view-modal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">View Movie In Player</h4>
        <button type="button" class="close close-modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      	<h3>Quality</h3>
      	<hr />
        <center><div class="btn-group" id="qlf"></div></center>
        <hr />
        <div id="player"></div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger close-modal">Close</button>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('plugins.Select2', true); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$("select.select-multiple").select2();

		<?php if($type == 'edit'): ?>
			$("select.select-multiple").val([<?php $__currentLoopData = $data->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'<?php echo e($category->id); ?>',<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]).trigger('change');
		<?php endif; ?>

		$(".test-movie").click(function(){
			let api_code = $(this).attr('data-code');

			$.post("<?php echo e(route('getDataVideo')); ?>", { api_code: api_code, _token: "<?php echo e(csrf_token()); ?>" }, function(data){
				let files = JSON.parse(data);
				
		    	let html = "";
		    	$("#qlf").empty();
		    	$.each(files.data, function(index, value){
		    		html+="<button class='btn btn-info set-player' data-url='"+value.file+"' type='button'>"+value.label+"</button>";
		    	});
		    	$("#qlf").html(html);
		    	html = "";
			});

			$('#movie-view-modal').modal('show');
		});

		$("body").on('click','button.set-player', function(){
			let url_player = $(this).attr("data-url");

			$("#player").empty();
			$("#player").html("<video width='100%' height='240' controls><source src='<?php echo e(route('getVideo')); ?>?video_url="+url_player+"' type='video/mp4'/></video>");
		});

		$(".close-modal").click(function(){
			$("#player").empty();
			$('#movie-view-modal').modal('hide');
		});
	});
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/movie-admin/resources/views/admin/movies/form.blade.php ENDPATH**/ ?>